Version statique Hadriproduction.
À déposer sur Netlify : index.html uniquement.
Pas de PHP, pas de Supabase, pas d'admin.
